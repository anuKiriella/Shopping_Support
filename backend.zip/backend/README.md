# qr-analyzer-fast-api

This is student result prediction application

Create virtual envirment : python -m venv myenv

ACTIVATE VENV: source myenv/Scripts/activate

Create Requirment File: pip freeze > requirements.txt


requirement.text install: pip install -r requirements.txt

RUN SERVER: uvicorn index:app --reload

Test Api: http://localhost:8000/docs

app psw: axsrbizmfuepylid
